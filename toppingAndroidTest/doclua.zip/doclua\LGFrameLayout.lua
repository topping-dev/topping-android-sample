-------------------------------------------------------------------------------

---@class LGFrameLayout:LGViewGroup
local LGFrameLayout = Class()

-------------------------------------------------------------------------------
---@function Creates LGFrameLayout Object From Lua.
---@param lc LuaContext
---@return LGFrameLayout
function LGFrameLayout.Create(lc)
end

_G['LGFrameLayout'] = LGFrameLayout
return LGFrameLayout

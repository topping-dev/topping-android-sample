-------------------------------------------------------------------------------

---@class LGAbsListView
local LGAbsListView = Class()

-------------------------------------------------------------------------------
---@function Creates LGAbsListView Object From Lua. Do not use this class directly
---@param lc LuaContext
---@return LGAbsListView
function LGAbsListView.Create(lc)
end

_G['LGAbsListView'] = LGAbsListView
return LGAbsListView

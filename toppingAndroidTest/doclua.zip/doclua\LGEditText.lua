-------------------------------------------------------------------------------

---@class LGEditText
local LGEditText = Class()

-------------------------------------------------------------------------------
---@function Creates LGEditText Object From Lua.
---@param lc LuaContext
---@return LGEditText
function LGEditText.Create(lc)
end

_G['LGEditText'] = LGEditText
return LGEditText

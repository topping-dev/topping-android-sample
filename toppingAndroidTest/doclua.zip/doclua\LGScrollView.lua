-------------------------------------------------------------------------------

---@class LGScrollView:LGFrameLayout
local LGScrollView = Class()

-------------------------------------------------------------------------------
---@function Creates LGScrollView Object From Lua.
---@param lc LuaContext
---@return LGScrollView
function LGScrollView.Create(lc)
end

_G['LGScrollView'] = LGScrollView
return LGScrollView

-------------------------------------------------------------------------------

---@class LGConstraintLayout:LGViewGroup
local LGConstraintLayout = Class()

-------------------------------------------------------------------------------
---@function Creates LGConstraintLayout Object From Lua.
---@param lc LuaContext
---@return LGConstraintLayout
function LGConstraintLayout.Create(lc)
end

_G['LGConstraintLayout'] = LGConstraintLayout
return LGConstraintLayout

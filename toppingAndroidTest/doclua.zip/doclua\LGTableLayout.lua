-------------------------------------------------------------------------------

---@class LGTableLayout:LGLinearLayout
local LGTableLayout = Class()

-------------------------------------------------------------------------------
---@function Creates LGTableLayout Object From Lua.
---@param lc LuaContext
---@return LGTableLayout
function LGTableLayout.Create(lc)
end

_G['LGTableLayout'] = LGTableLayout
return LGTableLayout

-------------------------------------------------------------------------------

---@class LGViewGroup
local LGViewGroup = Class()

-------------------------------------------------------------------------------
---@function Creates LGViewGroup Object From Lua. Do not create this class directly.
---@param lc LuaContext
---@return LGViewGroup
function LGViewGroup.Create(lc)
end

_G['LGViewGroup'] = LGViewGroup
return LGViewGroup

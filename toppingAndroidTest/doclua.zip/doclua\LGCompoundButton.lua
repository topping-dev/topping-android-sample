-------------------------------------------------------------------------------

---@class LGCompoundButton:LGButton
local LGCompoundButton = Class()

-------------------------------------------------------------------------------
---@function Creates LGCompoundButton Object From Lua.
---@param lc LuaContext
---@return LGCompoundButton
function LGCompoundButton.Create(lc)
end

_G['LGCompoundButton'] = LGCompoundButton
return LGCompoundButton

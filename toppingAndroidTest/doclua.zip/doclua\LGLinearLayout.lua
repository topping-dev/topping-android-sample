-------------------------------------------------------------------------------

---@class LGLinearLayout
local LGLinearLayout = Class()

-------------------------------------------------------------------------------
---@function Creates LGLinearLayout Object From Lua.
---@param lc LuaContext
---@return LGLinearLayout
function LGLinearLayout.Create(lc)
end

_G['LGLinearLayout'] = LGLinearLayout
return LGLinearLayout

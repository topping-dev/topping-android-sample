-------------------------------------------------------------------------------

---@class LGListViewFragment:ListFragment
local LGListViewFragment = Class()

_G['LGListViewFragment'] = LGListViewFragment
return LGListViewFragment

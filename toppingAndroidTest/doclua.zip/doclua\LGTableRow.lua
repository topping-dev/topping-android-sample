-------------------------------------------------------------------------------

---@class LGTableRow
local LGTableRow = Class()

-------------------------------------------------------------------------------
---@function Creates LGTableRow Object From Lua.
---@param lc LuaContext
---@return LGTableRow
function LGTableRow.Create(lc)
end

_G['LGTableRow'] = LGTableRow
return LGTableRow

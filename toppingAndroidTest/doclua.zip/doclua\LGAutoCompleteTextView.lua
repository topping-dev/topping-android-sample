-------------------------------------------------------------------------------

---@class LGAutoCompleteTextView:LGEditText
local LGAutoCompleteTextView = Class()

-------------------------------------------------------------------------------
---@function Creates LGAutoCompleteTextView Object From Lua.
---@param lc LuaContext
---@return LGAutoCompleteTextView
function LGAutoCompleteTextView.Create(lc)
end

_G['LGAutoCompleteTextView'] = LGAutoCompleteTextView
return LGAutoCompleteTextView

-------------------------------------------------------------------------------

---@class LuaDefines:LuaInterface
local LuaDefines = Class()

_G['LuaDefines'] = LuaDefines
return LuaDefines

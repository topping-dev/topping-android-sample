-------------------------------------------------------------------------------

---@class LGToolbar:LGView
local LGToolbar = Class()

_G['LGToolbar'] = LGToolbar
return LGToolbar

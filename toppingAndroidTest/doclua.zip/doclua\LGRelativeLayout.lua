-------------------------------------------------------------------------------

---@class LGRelativeLayout
local LGRelativeLayout = Class()

-------------------------------------------------------------------------------
---@function Creates LGRelativeLayout Object From Lua.
---@param lc LuaContext
---@return LGRelativeLayout
function LGRelativeLayout.Create(lc)
end

_G['LGRelativeLayout'] = LGRelativeLayout
return LGRelativeLayout

-------------------------------------------------------------------------------

---@class LuaNativeObject:LuaInterface
local LuaNativeObject = Class()

_G['LuaNativeObject'] = LuaNativeObject
return LuaNativeObject

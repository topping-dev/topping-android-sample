-------------------------------------------------------------------------------

---@class LGHorizontalScrollView
local LGHorizontalScrollView = Class()

-------------------------------------------------------------------------------
---@function Creates LGHorizontalScrollView Object From Lua.
---@param lc LuaContext
---@return LGHorizontalScrollView
function LGHorizontalScrollView.Create(lc)
end

_G['LGHorizontalScrollView'] = LGHorizontalScrollView
return LGHorizontalScrollView

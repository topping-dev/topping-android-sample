-------------------------------------------------------------------------------

---@class LGButton:LGTextView
local LGButton = Class()

-------------------------------------------------------------------------------
---@function Creates LGButton Object From Lua.
---@param lc LuaContext
---@return LGButton
function LGButton.Create(lc)
end

_G['LGButton'] = LGButton
return LGButton
